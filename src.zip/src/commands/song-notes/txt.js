//txt song notes info file (courtesy: Mini)
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports={
    name: 'txt',
    description: 'Shows txt song information.',

    async execute(msg, args) {
        const pages=[
            {
                title: '**The Dream Chapter: Star**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641123141390388/ab67616d000082c18bb3d891b76c7850cf34fd40.png?ex=67c54974&is=67c3f7f4&hm=581980444d8582ba44a224221a3c45f855c0ae6677892c60550768b65dd769c5&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 1/13',
                fields: [
                    {
                        name: '**Crown | `lvl.13`**',
                        value: '__Short notes:__ `532` __Short length:__ `1:47`\n__Full notes:__ `1175` __Full length:__ `3:51`'
                    },
                    {
                        name: '**Our Summer | `lvl.12`**',
                        value: '__Short notes:__ `379` __Short length:__ `1:00`\n__Full notes:__ `1316` __Full length:__ `3:30`'
                    },
                    {
                        name: '**Cat & Dog | `lvl.13`**',
                        value: '__Short notes:__ `616` __Short length:__ `1:44`\n__Full notes:__ `1134` __Full length:__ `3:08`'
                    },
                    {
                        name: '**Blue Orangeade | `lvl.15`**',
                        value: '__Short notes:__ `531` __Short length:__ `1:19`\n__Full notes:__ `1251` __Full length:__ `3:06`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Nap of a Star | `lvl.5`**',
                        value: '__Short notes:__ `231` __Short length:__ `1:56`\n__Full notes:__ `1157` __Full length:__ `4:03`'
                    },
                ]
            },
            {
                title: '**The Dream Chapter: Magic**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641123485319178/ab67616d000082c19389aab1165b6498eba04d8e.png?ex=67c54974&is=67c3f7f4&hm=c31095b1002c02f6f85161030d18fc99aecd9bf852d012ebf5f7a13463844035&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 2/13',
                fields: [
                    {
                        name: '**Run Away | `lvl.11`**',
                        value: '__Short notes:__ `466` __Short length:__ `1:29`\n__Full notes:__ `1123` __Full length:__ `3:32`'
                    },
                    {
                        name: '**Poppin\' Star | `lvl.13`**',
                        value: '__Short notes:__ `380` __Short length:__ `1:10`\n__Full notes:__ `1204` __Full length:__ `3:13`'
                    },
                    {
                        name: '**Can\'t We Just Leave The Monster Alive? | `lvl.16`**',
                        value: '__Short notes:__ `581` __Short length:__ `1:28`\n__Full notes:__ `1626` __Full length:__ `3:50`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Magic Island | `lvl.3`**',
                        value: '__Short notes:__ `282` __Short length:__ `1:20`\n__Full notes:__ `732` __Full length:__ `3:13`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Angel Or Devil | `lvl.6`**',
                        value: '__Short notes:__ `487` __Short length:__ `1:41`\n__Full notes:__ `1228` __Full length:__ `3:52`'
                    },
                    {
                        name: '**New Rules | `lvl.14`**',
                        value: '__Short notes:__ `626` __Short length:__ `1:38`\n__Full notes:__ `1120` __Full length:__ `2:54`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Roller Coaster | `lvl.13`**',
                        value: '__Short notes:__ `672` __Short length:__ `1:39`\n__Full notes:__ `1487` __Full length:__ `3:34`'
                    },
                    {
                        name: '**20cm | `lvl.11`**',
                        value: '__Short notes:__ `359` __Short length:__ `1:20`\n__Full notes:__ `1037` __Full length:__ `3:37`'
                    },
                ]
            },
            {
                title: '**The Dream Chapter: Eternity**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641123753758790/ab67616d000082c1b85b1b3fae4244c686929af5.png?ex=67c54974&is=67c3f7f4&hm=aadde057c864dcdc5d6cc92916bee779a2cbd83450563e717ce49158ce25d5cb&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 3/13',
                fields: [
                    {
                        name: '**Can\'t You See Me? | `lvl.12`**',
                        value: '__Short notes:__ `425` __Short length:__ `1:33`\n__Full notes:__ `1011` __Full length:__ `3:21`'
                    },
                    {
                        name: '**Puma | `lvl.13`**',
                        value: '__Short notes:__ `559` __Short length:__ `1:40`\n__Full notes:__ `1205` __Full length:__ `3:26`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Maze in the Mirror | `lvl.11`**',
                        value: '__Short notes:__ `637` __Short length:__ `1:40`\n__Full notes:__ `1349` __Full length:__ `3:46`'
                    },
                    {
                        name: '**Eternally | `lvl.13`**',
                        value: '__Short notes:__ `667` __Short length:__ `1:53`\n__Full notes:__ `1342` __Full length:__ `3:37`'
                    },
                    {
                        name: '**Drama | `lvl.14`**',
                        value: '__Short notes:__ `432` __Short length:__ `1:14`\n__Full notes:__ `1335` __Full length:__ `3:30`'
                    },
                ]
            },
            {
                title: '**Minisode 1: Blue Hour**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641124064133181/ab67616d000082c18c6cdb00ed42b1d6315f0bc1.png?ex=67c54974&is=67c3f7f4&hm=d686fb0db37a62f619521b6e222b705ab6dc1a42c246beca3153ed432481ad0e&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 4/13',
                fields: [
                    {
                        name: '**Blue Hour | `lvl.12`**',
                        value: '__Short notes:__ `423` __Short length:__ `1:30`\n__Full notes:__ `1061` __Full length:__ `3:29`'
                    },
                    {
                        name: '**We Lost The Summer | `lvl.13`**',
                        value: '__Short notes:__ `642` __Short length:__ `1:43`\n__Full notes:__ `1372` __Full length:__ `3:31`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Way Home | `lvl.6`**',
                        value: '__Short notes:__ `371` __Short length:__ `1:13`\n__Full notes:__ `980` __Full length:__ `3:03`'
                    },
                    {
                        name: '**Wishlist | `lvl.15`**',
                        value: '__Short notes:__ `496` __Short length:__ `1:15`\n__Full notes:__ `1324` __Full length:__ `3:12`'
                    },
                    {
                        name: '**Ghosting | `lvl.13`**',
                        value: '__Short notes:__ `429` __Short length:__ `1:22`\n__Full notes:__ `1338` __Full length:__ `3:43`'
                    },
                ]
            },
            {
                title: '**The Chaos Chapter: FREEZE**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641802006397022/ab67616d000082c1253a9c74941281b0407ce940.png?ex=67c54a16&is=67c3f896&hm=b9128db28ab0a9fd6ec3f97456bd0ef90c2cbe075ea2222e1593f3e05e4ea310&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 5/13',
                fields: [
                    {
                        name: '**0X1=LOVESONG (I Know I Love You) feat. Seori | `lvl.11`**',
                        value: '__Short notes:__ `455` __Short length:__ `1:27`\n__Full notes:__ `1050` __Full length:__ `3:22`'
                    },
                    {
                        name: '**Magic | `lvl.14`**',
                        value: '__Short notes:__ `364` __Short length:__ `1:00`\n__Full notes:__ `1100` __Full length:__ `2:40`'
                    },
                    {
                        name: '**No Rules | `lvl.12`**',
                        value: '__Short notes:__ `288` __Short length:__ `1:03`\n__Full notes:__ `916` __Full length:__ `3:06`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Ice Cream | `lvl.11`**',
                        value: '__Short notes:__ `444` __Short length:__ `1:15`\n__Full notes:__ `1350` __Full length:__ `3:23`'
                    },
                    {
                        name: '**Frost | `lvl.13`**',
                        value: '__Short notes:__ `442` __Short length:__ `1:18`\n__Full notes:__ `1260` __Full length:__ `3:15`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Anti-Romantic | `lvl.5`**',
                        value: '__Short notes:__ `364` __Short length:__ `1:22`\n__Full notes:__ `1030` __Full length:__ `3:35`'
                    },
                    {
                        name: '**Dear Sputnik | `lvl.12`**',
                        value: '__Short notes:__ `393` __Short length:__ `1:11`\n__Full notes:__ `1164` __Full length:__ `3:15`'
                    },
                    {
                        name: '**What if I had been that PUMA | `lvl.14`**',
                        value: '__Short notes:__ `620` __Short length:__ `1:39`\n__Full notes:__ `1440` __Full length:__ `3:33`'
                    },
                ]
            },
            {
                title: '**The Chaos Chapter: FIGHT OR ESCAPE**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641802287550486/ab67616d000082c15137378ed49327e5dec7406f.png?ex=67c54a16&is=67c3f896&hm=3d471d4d1ed362c6b690233f268e76fb11ec963fd60687faaa82c3349ef0d11d&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 6/13',
                fields: [
                    {
                        name: '**LO$ER=LO♡ER | `lvl.11`**',
                        value: '__Short notes:__ `470` __Short length:__ `1:25`\n__Full notes:__ `1180` __Full length:__ `3:18`'
                    },
                    {
                        name: '**MOA Diary (Dubaddu Wari Wari) | `lvl.12`**',
                        value: '__Short notes:__ `302` __Short length:__ `1:06`\n__Full notes:__ `914` __Full length:__ `3:08`'
                    },
                ]
            },
            {
                title: '**Minisode 2: Thursday\'s Child**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641802559914054/ab67616d000082c113ac5d67675999ba7b9c4f21.png?ex=67c54a16&is=67c3f896&hm=b84dbc566cdd5d4a3c717775d04c50c62d740cad4818d92b097f9058e51fbab0&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 7/13',
                fields: [
                    {
                        name: '**Opening Sequence | `lvl.10`**',
                        value: '__Short notes:__ `296` __Short length:__ `1:16`\n__Full notes:__ `807` __Full length:__ `2:58`'
                    },
                    {
                        name: '**Good Boy Gone Bad | `lvl.11`**',
                        value: '__Short notes:__ `375` __Short length:__ `1:25`\n__Full notes:__ `973` __Full length:__ `3:11`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Trust Fund Baby | `lvl.4`**',
                        value: '__Short notes:__ `391` __Short length:__ `1:27`\n__Full notes:__ `749` __Full length:__ `2:36`'
                    },
                    {
                        name: '**Lonely Boy | `lvl.10`**',
                        value: '__Short notes:__ `225` __Short length:__ `0:53`\n__Full notes:__ `854` __Full length:__ `2:49`'
                    },
                    {
                        name: '**Thursday\'s Child Has Far To Go | `lvl.14`**',
                        value: '__Short notes:__ `451` __Short length:__ `1:18`\n__Full notes:__ `1445` __Full length:__ `3:31`'
                    },
                ]
            },
            {
                title: '**The Name Chapter: TEMPTATION**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345641802849325097/ab67616d000082c13bb056e3160b85ee86c1194d.png?ex=67c54a16&is=67c3f896&hm=1c59cb0762f66869ae9fe3445c197db5210543289a1038cf5cd4120327e9a6ae&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 8/13',
                fields: [
                    {
                        name: '**Sugar Rush Ride | `lvl.11`**',
                        value: '__Short notes:__ `292` __Short length:__ `1:00`\n__Full notes:__ `955` __Full length:__ `3:07`'
                    },
                    {
                        name: '**Devil by the Window | `lvl.11`**',
                        value: '__Short notes:__ `300` __Short length:__ `1:13`\n__Full notes:__ `742` __Full length:__ `3:06`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Farewell, Neverland | `lvl.5`**',
                        value: '__Short notes:__ `359` __Short length:__ `1:06`\n__Full notes:__ `995` __Full length:__ `3:01`'
                    },
                    {
                        name: '**<:nonrn:1344330008486740049> Tinnitus | `lvl.5`**',
                        value: '__Short notes:__ `365` __Short length:__ `1:22`\n__Full notes:__ `733` __Full length:__ `2:37`'
                    },
                    {
                        name: '**Happy Fools (feat. Coi Leray) | `lvl.14`**',
                        value: '__Short notes:__ `557` __Short length:__ `1:16`\n__Full notes:__ `1206` __Full length:__ `2:36`'
                    },
                ]
            },
            {
                title: '**The Name Chapter: FREEFALL**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345642587179974718/ab67616d000082c16067880e6c410727ac5a5f8b.png?ex=67c54ad1&is=67c3f951&hm=5b8c45812c3ae3b878b2cea9b00ac3b9cda77b69da05c4de2944a84aaf636036&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 9/13',
                fields: [
                    {
                        name: '**Back for More (TXT Ver.) | `lvl.13`**',
                        value: '__Short notes:__ `375` __Short length:__ `1:11`\n__Full notes:__ `965` __Full length:__ `2:42`'
                    },
                    {
                        name: '**Chasing That Feeling | `lvl.14`**',
                        value: '__Short notes:__ `380` __Short length:__ `1:05`\n__Full notes:__ `1245` __Full length:__ `3:02`'
                    },
                    {
                        name: '**Skipping Stones | `lvl.13`**',
                        value: '__Short notes:__ `311` __Short length:__ `1:15`\n__Full notes:__ `943` __Full length:__ `3:21`'
                    },
                    {
                        name: '**Happily Ever After | `lvl.13`**',
                        value: '__Short notes:__ `272` __Short length:__ `0:57`\n__Full notes:__ `835` __Full length:__ `2:31`'
                    },
                    {
                        name: '**Growing Pain | `lvl.15`**',
                        value: '__Short notes:__ `460` __Short length:__ `1:16`\n__Full notes:__ `1378` __Full length:__ `3:20`'
                    },
                    {
                        name: '**Deep Down | `lvl.13`**',
                        value: '__Short notes:__ `284` __Short length:__ `1:13`\n__Full notes:__ `900` __Full length:__ `2:44`'
                    },
                    {
                        name: '**Blue Spring | `lvl.12`**',
                        value: '__Short notes:__ `363` __Short length:__ `1:14`\n__Full notes:__ `1013` __Full length:__ `3:06`'
                    },
                    {
                        name: '**Dreamer | `lvl.11`**',
                        value: '__Short notes:__ `257` __Short length:__ `1:02`\n__Full notes:__ `910` __Full length:__ `3:06`'
                    },
                ]
            },
            {
                title: '**Minisode 3: TOMORROW**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345642587540951083/196922842283_Cover.png?ex=67c54ad1&is=67c3f951&hm=db4b54c7dd2461116530544a1782af336c7ed6f76fbc27570632e8b0ba3b0a78&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 10/13',
                fields: [
                    {
                        name: '**Deja Vu | `lvl.14`**',
                        value: '__Short notes:__ `372` __Short length:__ `1:04`\n__Full notes:__ `1050` __Full length:__ `2:51`'
                    },
                    {
                        name: '**I\'ll See You There Tomorrow | `lvl.17`**',
                        value: '__Short notes:__ `574` __Short length:__ `1:11`\n__Full notes:__ `1717` __Full length:__ `3:16`'
                    },
                    {
                        name: '**Miracle | `lvl.12`**',
                        value: '__Short notes:__ `373` __Short length:__ `1:08`\n__Full notes:__ `1000` __Full length:__ `2:43`'
                    },
                    {
                        name: '**The Killa (I Belong to You) | `lvl.13`**',
                        value: '__Short notes:__ `401` __Short length:__ `1:04`\n__Full notes:__ `1075` __Full length:__ `2:42`'
                    },
                    {
                        name: '**Quarter Life | `lvl.15`**',
                        value: '__Short notes:__ `364` __Short length:__ `0:56`\n__Full notes:__ `1200` __Full length:__ `2:29`'
                    },
                ]
            },
            {
                title: '**The Star Chapter: SANCTUARY**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345642588040069120/198704166372_Cover.png?ex=67c54ad1&is=67c3f951&hm=c74ae5518b148b05bfd3a86fca67f452bb66b057080aa11da4c91b5d8b4a1e93&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 11/13',
                fields: [
                    {
                        name: '**Over The Moon | `lvl.12`**',
                        value: '__Short notes:__ `266` __Short length:__ `0:56`\n__Full notes:__ `900` __Full length:__ `2:37`'
                    },
                    {
                        name: '**Heaven | `lvl.12`**',
                        value: '__Short notes:__ `266` __Short length:__ `1:01`\n__Full notes:__ `958` __Full length:__ `2:34`'
                    },
                ]
            },
            {
                title: '**Solo: `Yeonjun`**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345643779759276133/Gkj-LCxWcAA5FMc.png?ex=67c54bed&is=67c3fa6d&hm=3ab5b14b9936347521f267eae25c50f54c2657a7ecd6f719b1d50aa3f5cf2979&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 12/13',
                fields: [
                    {
                        name: '**GGUM | `lvl.15`**',
                        value: '__Short notes:__ `401` __Short length:__ `0:58`\n__Full notes:__ `1259` __Full length:__ `2:31`'
                    },
                ]
            },
            {
                title: '**Other songs**',
                thumbnail: 'https://media.discordapp.net/attachments/1341215784327843980/1345643780153282620/196922462627_Cover.png?ex=67c54bee&is=67c3fa6e&hm=fac322467686fa46661647e4fdaeb312535116b599852e76a98a0bd9ab7c74d5&=&format=webp&quality=lossless&width=663&height=663',
                footer: 'Page 13/13',
                fields: [
                    {
                        name: '**<:nonrn:1344330008486740049> Our Summer (Acoustic Mix) | `lvl.4`**',
                        value: '__Short notes:__ `299` __Short length:__ `1:10`\n__Full notes:__ `943` __Full length:__ `3:42`'
                    },
                    {
                        name: '**Do It Like That | `lvl.12`**',
                        value: '__Short notes:__ `245` __Short length:__ `0:42`\n__Full notes:__ `910` __Full length:__ `2:25`'
                    },
                ]
            }
  
        ]

        let currentPage=0;
        const txtembed = new EmbedBuilder()
        .setTitle(pages[currentPage].title)
        .addFields(pages[currentPage].fields)
        .setColor('#CDF7F6')
        .setThumbnail(pages[currentPage].thumbnail)
        .setFooter({ text: `Page ${currentPage+1}/${pages.length}` });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('first')
                    .setLabel('⏮️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('previous')
                    .setLabel('◀️')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('next')
                    .setLabel('▶️')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('last')
                    .setLabel('⏭️')
                    .setStyle(ButtonStyle.Secondary)
            );
    
    const txtmsg = await msg.channel.send({
        embeds: [txtembed],
        components: [row]
    });

    const filter = i => i.user.id === msg.author.id;
    const collector = txtmsg.createMessageComponentCollector({ time: 360000, filter });

    collector.on('collect', async i => {
        try {
            if (i.customId === 'first') {
                currentPage = 0;
            } else if (i.customId === 'previous') {
                currentPage--;
            } else if (i.customId === 'next') {
                currentPage++;
            } else if (i.customId === 'last') {
                currentPage = pages.length-1;
            }

            row.components[0].setDisabled(currentPage===0);
            row.components[1].setDisabled(currentPage===0);
            row.components[2].setDisabled(currentPage===pages.length-1);
            row.components[3].setDisabled(currentPage===pages.length-1);

             txtembed
                .setTitle(pages[currentPage].title)
                .setFields(pages[currentPage].fields)
                .setThumbnail(pages[currentPage].thumbnail)
                .setFooter({ text: `Page ${currentPage+1}/${pages.length}` });

            await i.update({
                embeds: [txtembed],
                components: [row]
            });
        } catch (error) {
            if (error.code !== 10062 && error.code !== 40060) {
                console.error('Button interaction error:', error);
            }
            collector.stop();
        }
    });

    collector.on('end', ()=>{
        try {
            txtmsg.edit({ components: [] }).catch(()=>{});
        } catch (error) {
            console.error('Error cleaning up comonents:', error);
        }
    });
    }
};